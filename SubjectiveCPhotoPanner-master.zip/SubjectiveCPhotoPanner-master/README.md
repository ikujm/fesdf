Subjective-C Photo Panner
======================

A small clone of Facebook Paper's motion based photo panner, built for the [Facebook Paper's Photo Panner](http://subjc.com/facebook-paper-photo-panner/) post on [Subjective-C](http://subjc.com).

![Subjective-C Photo Panner](https://dl.dropboxusercontent.com/u/444249/subjectivecpaper.jpg)